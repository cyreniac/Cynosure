package com.example.dell.cynosurefinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ExampleUnitTest extends AppCompatActivity {

    private static final android.R.attr R = ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_example_unit_test );
    }
}
