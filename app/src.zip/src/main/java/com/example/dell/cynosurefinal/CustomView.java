package com.example.dell.cynosurefinal;

import android.widget.TextView;

/**
 * Created by DELL on 4/25/2018.
 */

public class CustomView {
    private float textSize;

    public float getTextSize() {
        return textSize;
    }

    public int getMeasuredWidth() {
        return measuredWidth;
    }

    public void getPaddingRight() {
    }

    public void getPaddingTop() {
    }

    public void getPaddingBottom() {
    }

    public void setText(String nextWord, BufferType spannable) {
    }

    public void getText() {
    }

    public void setVisibility(int visible) {
    }

    public Color animate() {
    }
}
